module.exports = {
  mode: "jit",
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  safelist: [],
  theme: {
    extend: {},
  },
  plugins: [],
};
