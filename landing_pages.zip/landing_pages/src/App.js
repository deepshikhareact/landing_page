import React from "react";
import First from "./Components/First";
import Second from "./Components/Second";
import Third from "./Components/Third";
import Four from "./Components/Four";
import Five from "./Components/Five";
import Six from "./Components/Six";
import Seven from "./Components/Seven";
import Eight from "./Components/Eight";
import Nine from "./Components/Nine";
import Ten from "./Components/Ten";
import Elavan from "./Components/Elevan";
import LastCard from './Components/LastCard'

function App() {
  return (
    <div>
      <First />
      <Second />
      <Third />
      <Four />
      <Five />
      <Six />
      <Seven />
      <Eight />
      <Nine />
      <Ten />
      <Elavan />
      <LastCard />
    </div>
  );
}

export default App;
